# Windows AwesomeMiner Setup (remote control)

1. In AwesomeMiner on Windows, go to Options -> Miner Management -> Add -> Remote Agent
2. Use Auto-Discovery or manual IP and port (e.g. 192.168.1.50:9630)
3. If discovery fails ensure UDP 4068 and TCP 9630 are allowed in Windows firewall (LAN profile)
