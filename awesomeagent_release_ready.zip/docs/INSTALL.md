# Install Guide (Quick)

## One-line (recommended)
This downloads the release bundle and runs the installer.
```bash
curl -sSL https://raw.githubusercontent.com/Luzifer-Black/AwesomeMiner-Linux-Agent/main/installer/install.sh | sudo bash
```

## From ZIP (manual)
```bash
curl -L -o awesomeagent_bundle.zip "https://github.com/Luzifer-Black/AwesomeMiner-Linux-Agent/releases/download/v1.0/awesomeagent_final_bundle.zip"
unzip -o awesomeagent_bundle.zip
cd release_files || true
sudo bash installer/one_click_installer.sh
```

## Direct .deb (if you have it)
```bash
sudo dpkg -i awesomeagent_1.0_amd64_osdetect.deb
sudo apt --fix-broken install -y
sudo systemctl enable --now awesomeminer-agent.service
```
