Quick start (local build + install):

1) Install Go (if you want to compile native agent):
   sudo apt update && sudo apt install -y golang-go build-essential

2) Build binary:
   ./build.sh

3) Package and install:
   ./package_deb.sh 1.0
   sudo dpkg -i awesomeagent_1.0_amd64.deb
   sudo systemctl daemon-reload
   sudo systemctl enable --now awesomeminer-agent.service

4) Enable discovery on Windows (if needed) and add Remote Agent in AwesomeMiner.
