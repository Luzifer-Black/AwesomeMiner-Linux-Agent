#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v go >/dev/null 2>&1; then
  echo "Go not installed. Install with: sudo apt install -y golang-go"
  exit 2
fi
cd src
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 go build -ldflags="-s -w" -o ../awesomeminer-remoteagent
echo "Built: awesomeminer-remoteagent"
