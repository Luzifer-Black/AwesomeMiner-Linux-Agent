#!/bin/bash
set -euo pipefail
REPO_OWNER="Luzifer-Black"
REPO_NAME="AwesomeMiner-Linux-Agent"
ASSET="installer.zip"
TMP=$(mktemp -d)
API="https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/releases/latest"
TAG=$(curl -sfL "$API" | grep -m1 '\"tag_name\":' | cut -d'"' -f4 || true)
if [[ -z "$TAG" ]]; then TAG="v1.0"; fi
URL="https://github.com/${REPO_OWNER}/${REPO_NAME}/releases/download/${TAG}/${ASSET}"
cd "$TMP"
curl -sL -o asset.zip "$URL" || { echo "download failed"; exit 2; }
unzip -q asset.zip || true
FOUND=$(find . -type f -name "awesomeminer-remoteagent" -perm /111 -print -quit || true)
if [[ -n "$FOUND" ]]; then
  sudo install -m 755 "$FOUND" /usr/bin/awesomeagent || true
  echo "Installed /usr/bin/awesomeagent"
  exit 0
fi
echo "No binary found in release asset."
exit 3
