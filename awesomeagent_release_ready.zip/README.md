# AwesomeMiner Linux Agent

This repository contains the full AwesomeMiner Linux Agent project for Linux Mint / Ubuntu / Debian.

## One-Click Installer
Run this on the target Linux machine to install the agent from the latest GitHub release:

```bash
bash <(curl -s https://raw.githubusercontent.com/Luzifer-Black/AwesomeMiner-Linux-Agent/main/installer/install.sh)
```

## Alternative - direct one-liner using raw file
```bash
wget -qO- https://raw.githubusercontent.com/Luzifer-Black/AwesomeMiner-Linux-Agent/main/installer/install.sh | bash
```

## How releases are structured
- Create Git tag (e.g. `v1.0`) and push to GitHub
- GitHub Actions will build the release assets (ZIP and deb) and upload them
- Release must include:
  - `awesomeagent_final_bundle.zip` (installer + helpers)
  - `awesomeagent_1.0_amd64_osdetect.deb` (the .deb package)

## Auto-Update
The agent includes scripts that query the GitHub Releases API to detect the latest tag and download/install
updated `.deb` assets automatically.
