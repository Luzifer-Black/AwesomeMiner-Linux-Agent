#!/bin/bash
set -euo pipefail
REPO="Luzifer-Black/AwesomeMiner-Linux-Agent"
API="https://api.github.com/repos/${REPO}/releases/latest"
TAG=$(curl -sSfL "$API" | grep -m1 '\"tag_name\":' | cut -d'"' -f4 || true)
if [ -z "$TAG" ]; then echo "[auto_update] no tag found"; exit 2; fi
ASSET_URL=$(curl -sSfL "https://api.github.com/repos/${REPO}/releases/tags/${TAG}" | grep browser_download_url | grep "awesomeagent_" | head -n1 | cut -d'"' -f4 || true)
if [ -z "$ASSET_URL" ]; then echo "[auto_update] no deb asset found for tag $TAG"; exit 3; fi
TMP=$(mktemp -d)
cd "$TMP"
echo "[auto_update] Downloading $ASSET_URL"
curl -sL -o package.deb "$ASSET_URL"
sudo dpkg -i package.deb || sudo apt-get install -fy
echo "[auto_update] Installed package from $ASSET_URL"
