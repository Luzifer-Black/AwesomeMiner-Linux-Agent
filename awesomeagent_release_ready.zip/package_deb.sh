#!/bin/bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
VERSION="${1:-1.0}"
PKG="awesomeagent_${VERSION}_amd64.deb"
PKGDIR="$DIR/pkg"
rm -rf "$PKGDIR"
mkdir -p "$PKGDIR"/usr/bin "$PKGDIR"/lib/systemd/system "$PKGDIR"/DEBIAN
if [ -f "$DIR/awesomeminer-remoteagent" ]; then
  cp "$DIR/awesomeminer-remoteagent" "$PKGDIR"/usr/bin/awesomeagent
else
  echo "No built binary found at $DIR/awesomeminer-remoteagent"
  exit 2
fi
chmod 755 "$PKGDIR"/usr/bin/awesomeagent
cat > "$PKGDIR"/DEBIAN/control <<EOF
Package: awesomeagent
Version: $VERSION
Section: utils
Priority: optional
Architecture: amd64
Maintainer: Luzifer-Black <noreply@example.com>
Description: AwesomeMiner Remote Agent (native)
EOF
cat > "$PKGDIR"/lib/systemd/system/awesomeminer-agent.service <<'UNIT'
[Unit]
Description=AwesomeMiner Remote Agent
After=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/awesomeagent
Restart=always
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
UNIT
dpkg-deb --build "$PKGDIR" "$DIR/$PKG"
echo "Built $PKG"
