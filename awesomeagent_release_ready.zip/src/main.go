package main

import (
    "context"
    "flag"
    "fmt"
    "log"
    "net"
    "net/http"
    "os"
    "os/signal"
    "path/filepath"
    "syscall"
    "time"
)

var (
    listenAddr = flag.String("listen", "0.0.0.0:9630", "listen address for agent HTTP API (host:port)")
    logfile    = "/var/log/awesomeminer_agent.log"
    dataDir    = "/var/lib/awesomeminer_agent"
)

func ensureDirs() {
    os.MkdirAll("/var/log", 0755)
    os.MkdirAll(dataDir, 0755)
}

func heartbeat() {
    f, err := os.OpenFile(logfile, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
    if err != nil {
        log.Println("heartbeat: failed open log:", err)
        return
    }
    defer f.Close()
    t := time.Now().Format(time.RFC3339)
    fmt.Fprintf(f, "[heartbeat] %s PID:%d\n", t, os.Getpid())
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
    w.Write([]byte("OK"))
}

func updateHandler(w http.ResponseWriter, r *http.Request) {
    p := filepath.Join(dataDir, "update.trigger")
    os.MkdirAll(filepath.Dir(p), 0755)
    f, err := os.Create(p)
    if err != nil {
        http.Error(w, "failed", 500)
        return
    }
    _ = f.Close()
    w.Write([]byte("update triggered"))
}

func infoHandler(w http.ResponseWriter, r *http.Request) {
    hostname, _ := os.Hostname()
    w.Header().Set("Content-Type", "application/json")
    fmt.Fprintf(w, `{"hostname":"%s","pid":%d}`, hostname, os.Getpid())
}

func localOnly(r *http.Request) bool {
    ipStr, _, err := net.SplitHostPort(r.RemoteAddr)
    if err != nil {
        ipStr = r.RemoteAddr
    }
    ip := net.ParseIP(ipStr)
    if ip == nil {
        return false
    }
    if ip.IsLoopback() {
        return true
    }
    if ip4 := ip.To4(); ip4 != nil {
        first := ip4[0]
        second := ip4[1]
        if first == 10 {
            return true
        }
        if first == 192 && second == 168 {
            return true
        }
        if first == 172 && second >= 16 && second <= 31 {
            return true
        }
    }
    return false
}

func wrapLocalOnly(h http.HandlerFunc) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        if !localOnly(r) {
            http.Error(w, "forbidden", http.StatusForbidden)
            return
        }
        h(w, r)
    }
}

func main() {
    flag.Parse()
    ensureDirs()
    log.Println("AwesomeMiner agent starting, listening on", *listenAddr)

    mux := http.NewServeMux()
    mux.HandleFunc("/health", wrapLocalOnly(healthHandler))
    mux.HandleFunc("/update", wrapLocalOnly(updateHandler))
    mux.HandleFunc("/info", wrapLocalOnly(infoHandler))

    srv := &http.Server{
        Addr:    *listenAddr,
        Handler: mux,
    }

    ticker := time.NewTicker(60 * time.Second)
    go func() {
        for range ticker.C {
            heartbeat()
        }
    }()
    heartbeat()

    go func() {
        if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
            log.Fatalf("ListenAndServe error: %v", err)
        }
    }()

    stop := make(chan os.Signal, 1)
    signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
    <-stop
    log.Println("shutting down")
    ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer cancel()
    srv.Shutdown(ctx)
}
